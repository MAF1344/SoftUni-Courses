from .song import Song
from .album import Album
from .band import Band